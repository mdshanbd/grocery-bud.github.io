from django.apps import AppConfig


class BookslistappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BooksListApp'
