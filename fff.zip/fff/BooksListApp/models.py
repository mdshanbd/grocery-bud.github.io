from django.db import models

# Create your models here.

class Author(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    age = models.CharField(max_length=50)
    book_name = models.CharField(max_length=50)
    publish_date = models.DateField()
    rating_category = ((1, "Worst"),(2, "Bad"),(3, "Not Bad"),(4, "Good"),(5, "Excellent"),)
    book_rating = models.IntegerField(choices=rating_category)
    def __str__(self):
        return self.first_name + " " + self.book_name + ", Book Rating " + str(self.book_rating)

