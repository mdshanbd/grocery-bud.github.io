from django.shortcuts import render
from .models import Author
# Create your views here.

def home(request):
    author_list = Author.objects.all()
    diction = {
        'text': 'All Boooks is here',
        'author_list': author_list,
    }
    return render(request, 'index.html', context=diction)